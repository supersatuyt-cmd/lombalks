import { Card, CardContent } from "@/components/ui/card"
import { Calendar, MapPin, CheckCircle2 } from "lucide-react"

const timelineEvents = [
  {
    date: "1 - 31 Januari 2024",
    title: "Pendaftaran Peserta",
    description: "Periode pendaftaran untuk seluruh peserta dari semua provinsi.",
    status: "completed",
  },
  {
    date: "1 - 28 Februari 2024",
    title: "Seleksi Tingkat Kabupaten/Kota",
    description: "Kompetisi tingkat kabupaten/kota untuk menyeleksi perwakilan.",
    status: "completed",
  },
  {
    date: "1 - 30 Maret 2024",
    title: "Seleksi Tingkat Provinsi",
    description: "Kompetisi tingkat provinsi untuk memilih wakil terbaik.",
    status: "active",
  },
  {
    date: "15 - 20 April 2024",
    title: "Pembekalan Peserta",
    description: "Pelatihan dan persiapan akhir untuk peserta tingkat nasional.",
    status: "upcoming",
  },
  {
    date: "1 - 7 Mei 2024",
    title: "LKS Tingkat Nasional",
    description: "Puncak kompetisi LKS tingkat nasional di Jakarta.",
    status: "upcoming",
  },
  {
    date: "8 Mei 2024",
    title: "Pengumuman & Award",
    description: "Pengumuman pemenang dan malam penghargaan LKS 2024.",
    status: "upcoming",
  },
]

export function TimelineSection() {
  return (
    <section id="timeline" className="py-20 bg-secondary/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto">
          <span className="text-primary font-semibold text-sm uppercase tracking-wider">Timeline</span>
          <h2 className="mt-4 text-3xl sm:text-4xl font-bold text-foreground text-balance">
            Jadwal Pelaksanaan LKS 2024
          </h2>
          <p className="mt-4 text-muted-foreground text-lg">
            Catat tanggal penting dan persiapkan dirimu untuk setiap tahapan kompetisi.
          </p>
        </div>
        
        {/* Timeline */}
        <div className="mt-16 relative">
          {/* Vertical line */}
          <div className="absolute left-4 md:left-1/2 top-0 bottom-0 w-0.5 bg-border md:-translate-x-1/2" />
          
          <div className="space-y-8">
            {timelineEvents.map((event, index) => (
              <div 
                key={index}
                className={`relative flex flex-col md:flex-row gap-4 md:gap-8 ${
                  index % 2 === 0 ? "md:flex-row" : "md:flex-row-reverse"
                }`}
              >
                {/* Timeline dot */}
                <div className={`absolute left-4 md:left-1/2 w-4 h-4 rounded-full md:-translate-x-1/2 z-10 ${
                  event.status === "completed" 
                    ? "bg-primary" 
                    : event.status === "active" 
                    ? "bg-accent ring-4 ring-accent/30" 
                    : "bg-muted-foreground/30"
                }`}>
                  {event.status === "completed" && (
                    <CheckCircle2 className="w-4 h-4 text-primary-foreground" />
                  )}
                </div>
                
                {/* Content */}
                <div className={`md:w-1/2 pl-12 md:pl-0 ${index % 2 === 0 ? "md:pr-12 md:text-right" : "md:pl-12"}`}>
                  <Card className={`${event.status === "active" ? "border-accent shadow-lg" : ""}`}>
                    <CardContent className="p-6">
                      <div className={`flex items-center gap-2 text-sm font-medium mb-2 ${
                        index % 2 === 0 ? "md:justify-end" : ""
                      } ${event.status === "active" ? "text-accent" : "text-muted-foreground"}`}>
                        <Calendar className="w-4 h-4" />
                        {event.date}
                      </div>
                      <h3 className="text-lg font-semibold text-foreground">{event.title}</h3>
                      <p className="mt-2 text-muted-foreground">{event.description}</p>
                      {event.status === "active" && (
                        <span className="inline-flex items-center gap-1 mt-3 px-3 py-1 rounded-full bg-accent/10 text-accent text-sm font-medium">
                          <span className="relative flex h-2 w-2">
                            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-accent opacity-75"></span>
                            <span className="relative inline-flex rounded-full h-2 w-2 bg-accent"></span>
                          </span>
                          Sedang Berlangsung
                        </span>
                      )}
                    </CardContent>
                  </Card>
                </div>
                
                {/* Empty space for alternating layout */}
                <div className="hidden md:block md:w-1/2" />
              </div>
            ))}
          </div>
        </div>
        
        {/* Location Info */}
        <div className="mt-16">
          <Card className="bg-primary text-primary-foreground">
            <CardContent className="p-8 flex flex-col md:flex-row items-center justify-between gap-6">
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 rounded-full bg-primary-foreground/10 flex items-center justify-center">
                  <MapPin className="w-8 h-8" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold">Lokasi Final LKS Nasional</h3>
                  <p className="text-primary-foreground/80">Jakarta Convention Center, Jakarta</p>
                </div>
              </div>
              <a 
                href="#" 
                className="inline-flex items-center gap-2 px-6 py-3 rounded-lg bg-primary-foreground text-primary font-medium hover:bg-primary-foreground/90 transition-colors"
              >
                Lihat di Maps
              </a>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  )
}
