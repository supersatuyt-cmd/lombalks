export function TrophyIllustration({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 400 400"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      {/* Background glow */}
      <circle cx="200" cy="200" r="160" fill="#3B82F6" fillOpacity="0.08" />
      
      {/* Trophy Cup */}
      <path
        d="M130 100H270V130C270 190 245 240 200 260C155 240 130 190 130 130V100Z"
        fill="url(#trophyGradient)"
      />
      
      {/* Cup Rim */}
      <rect x="120" y="90" width="160" height="18" rx="6" fill="#FBBF24" />
      
      {/* Left Handle */}
      <path
        d="M130 120C90 120 80 150 80 170C80 195 100 210 130 200"
        fill="none"
        stroke="#F59E0B"
        strokeWidth="14"
        strokeLinecap="round"
      />
      
      {/* Right Handle */}
      <path
        d="M270 120C310 120 320 150 320 170C320 195 300 210 270 200"
        fill="none"
        stroke="#F59E0B"
        strokeWidth="14"
        strokeLinecap="round"
      />
      
      {/* Stem */}
      <rect x="175" y="260" width="50" height="50" fill="#F59E0B" />
      
      {/* Base */}
      <rect x="145" y="310" width="110" height="20" rx="4" fill="#FBBF24" />
      <rect x="130" y="325" width="140" height="25" rx="6" fill="#F59E0B" />
      
      {/* Star */}
      <path
        d="M200 130L215 165H252L222 188L234 225L200 200L166 225L178 188L148 165H185L200 130Z"
        fill="#3B82F6"
      />
      
      {/* Shine */}
      <ellipse cx="155" cy="150" rx="12" ry="30" fill="white" fillOpacity="0.35" />
      
      {/* Sparkles */}
      <circle cx="90" cy="80" r="8" fill="#3B82F6" fillOpacity="0.6" />
      <circle cx="310" cy="90" r="6" fill="#F59E0B" fillOpacity="0.6" />
      <circle cx="70" cy="200" r="5" fill="#60A5FA" fillOpacity="0.5" />
      <circle cx="330" cy="180" r="7" fill="#FBBF24" fillOpacity="0.5" />
      
      <defs>
        <linearGradient id="trophyGradient" x1="130" y1="100" x2="270" y2="260" gradientUnits="userSpaceOnUse">
          <stop stopColor="#FCD34D" />
          <stop offset="0.5" stopColor="#FBBF24" />
          <stop offset="1" stopColor="#F59E0B" />
        </linearGradient>
      </defs>
    </svg>
  )
}

export function HeroIllustration({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 600 500"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      {/* Background shapes */}
      <circle cx="300" cy="250" r="220" fill="#3B82F6" fillOpacity="0.06" />
      <circle cx="300" cy="250" r="160" fill="#3B82F6" fillOpacity="0.04" />
      
      {/* Podium */}
      {/* 2nd place - left */}
      <rect x="120" y="320" width="120" height="130" rx="8" fill="#94A3B8" />
      <rect x="130" y="330" width="100" height="30" fill="#64748B" fillOpacity="0.5" />
      <text x="180" y="400" textAnchor="middle" fill="white" fontSize="36" fontWeight="bold" fontFamily="sans-serif">2</text>
      
      {/* 1st place - center */}
      <rect x="240" y="260" width="120" height="190" rx="8" fill="#F59E0B" />
      <rect x="250" y="270" width="100" height="30" fill="#FBBF24" fillOpacity="0.5" />
      <text x="300" y="380" textAnchor="middle" fill="white" fontSize="48" fontWeight="bold" fontFamily="sans-serif">1</text>
      
      {/* 3rd place - right */}
      <rect x="360" y="350" width="120" height="100" rx="8" fill="#D97706" />
      <rect x="370" y="360" width="100" height="30" fill="#FBBF24" fillOpacity="0.3" />
      <text x="420" y="420" textAnchor="middle" fill="white" fontSize="32" fontWeight="bold" fontFamily="sans-serif">3</text>
      
      {/* Person on 2nd place */}
      <circle cx="180" cy="280" r="35" fill="#60A5FA" />
      <circle cx="180" cy="235" r="28" fill="#FECACA" />
      
      {/* Person on 1st place - with trophy */}
      <circle cx="300" cy="210" r="45" fill="#3B82F6" />
      <circle cx="300" cy="155" r="35" fill="#FEF3C7" />
      {/* Small trophy in hand */}
      <path d="M340 190L360 190V200C360 215 355 225 350 230C345 225 340 215 340 200V190Z" fill="#FBBF24" />
      <rect x="345" y="230" width="10" height="15" fill="#F59E0B" />
      <rect x="340" y="245" width="20" height="8" rx="2" fill="#FBBF24" />
      
      {/* Person on 3rd place */}
      <circle cx="420" cy="310" r="32" fill="#93C5FD" />
      <circle cx="420" cy="268" r="25" fill="#FED7AA" />
      
      {/* Confetti */}
      <rect x="100" y="100" width="12" height="12" rx="2" fill="#3B82F6" transform="rotate(15 100 100)" />
      <rect x="480" y="120" width="10" height="10" rx="2" fill="#F59E0B" transform="rotate(-20 480 120)" />
      <rect x="150" y="150" width="8" height="8" rx="1" fill="#FBBF24" transform="rotate(45 150 150)" />
      <rect x="450" y="180" width="10" height="10" rx="2" fill="#60A5FA" transform="rotate(30 450 180)" />
      <rect x="200" y="80" width="10" height="10" rx="2" fill="#F59E0B" transform="rotate(-15 200 80)" />
      <rect x="400" y="90" width="8" height="8" rx="1" fill="#3B82F6" transform="rotate(60 400 90)" />
      
      {/* Stars */}
      <path d="M520 200L525 212H538L528 220L532 233L520 224L508 233L512 220L502 212H515L520 200Z" fill="#FBBF24" />
      <path d="M80 220L84 230H95L86 237L90 248L80 241L70 248L74 237L65 230H76L80 220Z" fill="#60A5FA" />
      
      {/* Decorative dots */}
      <circle cx="550" cy="300" r="6" fill="#3B82F6" fillOpacity="0.4" />
      <circle cx="50" cy="350" r="8" fill="#F59E0B" fillOpacity="0.4" />
      <circle cx="530" cy="400" r="5" fill="#FBBF24" fillOpacity="0.3" />
      <circle cx="70" cy="280" r="6" fill="#60A5FA" fillOpacity="0.3" />
    </svg>
  )
}

export function ComputerIllustration({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 400 320"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      {/* Background */}
      <ellipse cx="200" cy="170" rx="180" ry="140" fill="#3B82F6" fillOpacity="0.05" />
      
      {/* Monitor */}
      <rect x="60" y="30" width="280" height="180" rx="12" fill="#1E293B" />
      <rect x="72" y="42" width="256" height="156" rx="6" fill="#0F172A" />
      
      {/* Screen Content */}
      <rect x="82" y="52" width="236" height="136" rx="4" fill="#1E293B" />
      
      {/* Code lines */}
      <rect x="95" y="68" width="50" height="8" rx="2" fill="#F59E0B" />
      <rect x="95" y="86" width="140" height="8" rx="2" fill="#64748B" />
      <rect x="110" y="104" width="100" height="8" rx="2" fill="#3B82F6" />
      <rect x="110" y="122" width="120" height="8" rx="2" fill="#64748B" />
      <rect x="110" y="140" width="70" height="8" rx="2" fill="#22C55E" />
      <rect x="95" y="158" width="90" height="8" rx="2" fill="#64748B" />
      
      {/* Browser dots */}
      <circle cx="250" cy="62" r="5" fill="#EF4444" />
      <circle cx="268" cy="62" r="5" fill="#FBBF24" />
      <circle cx="286" cy="62" r="5" fill="#22C55E" />
      
      {/* Stand */}
      <path d="M175 210H225V250H175V210Z" fill="#64748B" />
      <ellipse cx="200" cy="258" rx="60" ry="12" fill="#475569" />
      
      {/* Keyboard */}
      <rect x="80" y="280" width="240" height="35" rx="6" fill="#334155" />
      {/* Keys */}
      <rect x="95" y="288" width="210" height="6" rx="2" fill="#475569" />
      <rect x="95" y="300" width="210" height="6" rx="2" fill="#475569" />
      
      {/* Sparkles */}
      <circle cx="40" cy="80" r="6" fill="#3B82F6" fillOpacity="0.4" />
      <circle cx="360" cy="60" r="8" fill="#F59E0B" fillOpacity="0.4" />
      <circle cx="50" cy="200" r="5" fill="#60A5FA" fillOpacity="0.3" />
    </svg>
  )
}

export function MedalIllustration({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 200 220"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      {/* Ribbon */}
      <path d="M70 0H90L100 80L80 100L60 50L70 0Z" fill="#3B82F6" />
      <path d="M130 0H110L100 80L120 100L140 50L130 0Z" fill="#F59E0B" />
      
      {/* Medal outer */}
      <circle cx="100" cy="140" r="60" fill="url(#medalGrad)" />
      
      {/* Medal inner ring */}
      <circle cx="100" cy="140" r="48" fill="none" stroke="#FCD34D" strokeWidth="3" />
      
      {/* Medal center */}
      <circle cx="100" cy="140" r="42" fill="url(#medalInner)" />
      
      {/* Star */}
      <path
        d="M100 105L112 130H140L118 148L128 175L100 155L72 175L82 148L60 130H88L100 105Z"
        fill="#3B82F6"
      />
      
      {/* Number */}
      <text x="100" y="150" textAnchor="middle" fill="white" fontSize="24" fontWeight="bold" fontFamily="sans-serif">1</text>
      
      {/* Shine */}
      <ellipse cx="78" cy="118" rx="12" ry="6" fill="white" fillOpacity="0.3" transform="rotate(-30 78 118)" />
      
      <defs>
        <linearGradient id="medalGrad" x1="40" y1="80" x2="160" y2="200" gradientUnits="userSpaceOnUse">
          <stop stopColor="#FCD34D" />
          <stop offset="1" stopColor="#F59E0B" />
        </linearGradient>
        <linearGradient id="medalInner" x1="58" y1="98" x2="142" y2="182" gradientUnits="userSpaceOnUse">
          <stop stopColor="#FBBF24" />
          <stop offset="1" stopColor="#D97706" />
        </linearGradient>
      </defs>
    </svg>
  )
}

export function RocketIllustration({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 200 220"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      {/* Stars */}
      <circle cx="25" cy="30" r="3" fill="#3B82F6" fillOpacity="0.6" />
      <circle cx="175" cy="40" r="4" fill="#F59E0B" fillOpacity="0.6" />
      <circle cx="20" cy="120" r="2" fill="#60A5FA" fillOpacity="0.5" />
      <circle cx="180" cy="100" r="3" fill="#FBBF24" fillOpacity="0.5" />
      
      {/* Rocket body */}
      <path
        d="M100 20C100 20 70 70 70 120C70 170 85 190 100 200C115 190 130 170 130 120C130 70 100 20 100 20Z"
        fill="white"
        stroke="#E2E8F0"
        strokeWidth="3"
      />
      
      {/* Nose */}
      <path d="M100 20L82 60H118L100 20Z" fill="#3B82F6" />
      
      {/* Window */}
      <circle cx="100" cy="95" r="22" fill="#1E293B" />
      <circle cx="100" cy="95" r="16" fill="#3B82F6" />
      <ellipse cx="94" cy="90" rx="5" ry="7" fill="white" fillOpacity="0.4" />
      
      {/* Stripe */}
      <rect x="88" y="125" width="24" height="35" rx="2" fill="#F59E0B" />
      
      {/* Fins */}
      <path d="M70 140L45 185L70 175V140Z" fill="#3B82F6" />
      <path d="M130 140L155 185L130 175V140Z" fill="#3B82F6" />
      
      {/* Flame */}
      <ellipse cx="100" cy="210" rx="20" ry="12" fill="#F59E0B" />
      <ellipse cx="100" cy="208" rx="14" ry="8" fill="#FBBF24" />
      <ellipse cx="100" cy="206" rx="8" ry="5" fill="#FEF3C7" />
    </svg>
  )
}

export function TeamworkIllustration({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 400 300"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      {/* Background */}
      <circle cx="200" cy="150" r="120" fill="#3B82F6" fillOpacity="0.06" />
      
      {/* Puzzle pieces */}
      <g>
        {/* Top left - blue */}
        <path
          d="M90 70H155C155 70 155 85 170 85C185 85 185 70 185 70V135C185 135 170 135 170 150C170 165 185 165 185 165H90V70Z"
          fill="#3B82F6"
        />
        
        {/* Top right - orange */}
        <path
          d="M195 70H260C260 70 260 85 275 85C290 85 290 70 290 70V135C290 135 275 135 275 150C275 165 290 165 290 165H225C225 165 225 150 210 150C195 150 195 165 195 165V70Z"
          fill="#F59E0B"
        />
        
        {/* Bottom left - light blue */}
        <path
          d="M90 175H155C155 175 155 160 170 160C185 160 185 175 185 175V240H90V175Z"
          fill="#60A5FA"
        />
        
        {/* Bottom right - yellow */}
        <path
          d="M195 175C195 175 195 160 210 160C225 160 225 175 225 175H290V240H195V175Z"
          fill="#FBBF24"
        />
      </g>
      
      {/* Center checkmark */}
      <circle cx="190" cy="155" r="22" fill="white" />
      <path d="M180 155L188 163L202 147" stroke="#3B82F6" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" />
      
      {/* Decorative */}
      <circle cx="330" cy="60" r="8" fill="#F59E0B" fillOpacity="0.4" />
      <circle cx="60" cy="50" r="6" fill="#3B82F6" fillOpacity="0.4" />
      <circle cx="340" cy="200" r="5" fill="#FBBF24" fillOpacity="0.3" />
      <circle cx="50" cy="180" r="7" fill="#60A5FA" fillOpacity="0.3" />
    </svg>
  )
}

export function WavePattern({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 1440 200"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      preserveAspectRatio="none"
    >
      <path
        d="M0,100 C360,200 720,0 1080,100 C1260,150 1360,120 1440,100 L1440,200 L0,200 Z"
        fill="#3B82F6"
        fillOpacity="0.05"
      />
      <path
        d="M0,120 C320,180 640,60 960,120 C1200,160 1320,140 1440,120 L1440,200 L0,200 Z"
        fill="#3B82F6"
        fillOpacity="0.08"
      />
    </svg>
  )
}

export function GridPattern({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 100 100"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      <defs>
        <pattern id="grid" width="20" height="20" patternUnits="userSpaceOnUse">
          <circle cx="10" cy="10" r="1.5" fill="#3B82F6" fillOpacity="0.15" />
        </pattern>
      </defs>
      <rect width="100" height="100" fill="url(#grid)" />
    </svg>
  )
}

export function AchievementIllustration({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 300 250"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      {/* Background */}
      <circle cx="150" cy="125" r="110" fill="#3B82F6" fillOpacity="0.06" />
      
      {/* Certificate */}
      <rect x="60" y="60" width="180" height="130" rx="8" fill="white" stroke="#E2E8F0" strokeWidth="2" />
      
      {/* Certificate content */}
      <rect x="90" y="85" width="120" height="10" rx="3" fill="#64748B" fillOpacity="0.3" />
      <rect x="80" y="105" width="140" height="8" rx="2" fill="#94A3B8" fillOpacity="0.4" />
      <rect x="100" y="120" width="100" height="8" rx="2" fill="#94A3B8" fillOpacity="0.4" />
      
      {/* Medal on certificate */}
      <circle cx="150" cy="155" r="22" fill="#F59E0B" />
      <circle cx="150" cy="155" r="16" fill="#FBBF24" />
      <path d="M150 145L154 153H162L156 158L158 167L150 162L142 167L144 158L138 153H146L150 145Z" fill="#3B82F6" />
      
      {/* Ribbon */}
      <path d="M135 175L135 195L150 185L165 195L165 175" fill="#3B82F6" />
      
      {/* Stars */}
      <path d="M50 50L53 58H62L55 63L58 72L50 66L42 72L45 63L38 58H47L50 50Z" fill="#FBBF24" />
      <path d="M250 60L253 68H262L255 73L258 82L250 76L242 82L245 73L238 68H247L250 60Z" fill="#60A5FA" />
      
      {/* Decorative */}
      <circle cx="270" cy="180" r="6" fill="#F59E0B" fillOpacity="0.4" />
      <circle cx="30" cy="150" r="5" fill="#3B82F6" fillOpacity="0.4" />
    </svg>
  )
}

export function SkillsIllustration({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 400 300"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      {/* Background */}
      <circle cx="200" cy="150" r="130" fill="#3B82F6" fillOpacity="0.05" />
      
      {/* Gear 1 - Large */}
      <g>
        <circle cx="160" cy="140" r="50" fill="#3B82F6" />
        <circle cx="160" cy="140" r="35" fill="#60A5FA" />
        <circle cx="160" cy="140" r="15" fill="#3B82F6" />
        {/* Teeth */}
        <rect x="150" y="85" width="20" height="15" fill="#3B82F6" />
        <rect x="150" y="180" width="20" height="15" fill="#3B82F6" />
        <rect x="105" y="130" width="15" height="20" fill="#3B82F6" />
        <rect x="200" y="130" width="15" height="20" fill="#3B82F6" />
      </g>
      
      {/* Gear 2 - Small */}
      <g>
        <circle cx="250" cy="120" r="35" fill="#F59E0B" />
        <circle cx="250" cy="120" r="24" fill="#FBBF24" />
        <circle cx="250" cy="120" r="10" fill="#F59E0B" />
        {/* Teeth */}
        <rect x="242" y="82" width="16" height="12" fill="#F59E0B" />
        <rect x="242" y="146" width="16" height="12" fill="#F59E0B" />
        <rect x="212" y="112" width="12" height="16" fill="#F59E0B" />
        <rect x="276" y="112" width="12" height="16" fill="#F59E0B" />
      </g>
      
      {/* Lightbulb */}
      <g>
        <path d="M300 180C300 165 285 155 285 140C285 120 305 105 325 105C345 105 365 120 365 140C365 155 350 165 350 180H300Z" fill="#FBBF24" />
        <rect x="305" y="185" width="40" height="8" rx="2" fill="#F59E0B" />
        <rect x="310" y="197" width="30" height="8" rx="2" fill="#F59E0B" />
        <rect x="315" y="209" width="20" height="8" rx="4" fill="#94A3B8" />
        {/* Light rays */}
        <line x1="325" y1="80" x2="325" y2="60" stroke="#FBBF24" strokeWidth="4" strokeLinecap="round" />
        <line x1="280" y1="105" x2="265" y2="90" stroke="#FBBF24" strokeWidth="4" strokeLinecap="round" />
        <line x1="370" y1="105" x2="385" y2="90" stroke="#FBBF24" strokeWidth="4" strokeLinecap="round" />
      </g>
      
      {/* Decorative */}
      <circle cx="80" cy="80" r="8" fill="#60A5FA" fillOpacity="0.4" />
      <circle cx="350" cy="240" r="6" fill="#F59E0B" fillOpacity="0.4" />
      <circle cx="60" cy="200" r="5" fill="#3B82F6" fillOpacity="0.3" />
    </svg>
  )
}
