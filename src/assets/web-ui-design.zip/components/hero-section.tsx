import { Button } from "@/components/ui/button"
import { GridPattern } from "@/components/illustrations"
import { ArrowRight, Play } from "lucide-react"
import Image from "next/image"

export function HeroSection() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-16">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-50">
        <GridPattern className="w-full h-full" />
      </div>
      
      {/* Decorative circles */}
      <div className="absolute top-20 left-10 w-72 h-72 bg-primary/10 rounded-full blur-3xl" />
      <div className="absolute bottom-20 right-10 w-96 h-96 bg-accent/10 rounded-full blur-3xl" />
      
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div className="text-center lg:text-left">
            {/* Badge */}
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary text-sm font-medium mb-6">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-primary"></span>
              </span>
              Pendaftaran Dibuka
            </div>
            
            {/* Main Heading */}
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-foreground leading-tight text-balance">
              Lomba Kompetensi{" "}
              <span className="text-primary">Siswa</span>{" "}
              <span className="text-accent">2024</span>
            </h1>
            
            <p className="mt-6 text-lg text-muted-foreground max-w-xl mx-auto lg:mx-0 text-pretty">
              Wujudkan potensimu dan raih prestasi gemilang di ajang kompetisi paling bergengsi untuk siswa SMK se-Indonesia.
            </p>
            
            {/* Stats */}
            <div className="mt-8 flex flex-wrap justify-center lg:justify-start gap-8">
              <div>
                <p className="text-3xl font-bold text-foreground">50+</p>
                <p className="text-sm text-muted-foreground">Bidang Lomba</p>
              </div>
              <div>
                <p className="text-3xl font-bold text-foreground">34</p>
                <p className="text-sm text-muted-foreground">Provinsi</p>
              </div>
              <div>
                <p className="text-3xl font-bold text-foreground">10K+</p>
                <p className="text-sm text-muted-foreground">Peserta</p>
              </div>
            </div>
            
            {/* CTA Buttons */}
            <div className="mt-10 flex flex-wrap justify-center lg:justify-start gap-4">
              <Button size="lg" className="gap-2">
                Daftar Sekarang
                <ArrowRight className="w-4 h-4" />
              </Button>
              <Button size="lg" variant="outline" className="gap-2">
                <Play className="w-4 h-4" />
                Lihat Video
              </Button>
            </div>
          </div>
          
          {/* Right Content - Illustration */}
          <div className="relative flex justify-center lg:justify-end">
            <div className="relative">
              {/* Floating elements */}
              <div className="absolute -top-4 -left-4 w-20 h-20 bg-accent/20 rounded-2xl animate-bounce" style={{ animationDelay: "0s", animationDuration: "3s" }} />
              <div className="absolute -bottom-4 -right-4 w-16 h-16 bg-primary/20 rounded-full animate-bounce" style={{ animationDelay: "1s", animationDuration: "4s" }} />
              <div className="absolute top-1/2 -left-8 w-12 h-12 bg-accent/30 rounded-lg animate-bounce" style={{ animationDelay: "0.5s", animationDuration: "3.5s" }} />
              
              {/* Main Illustration */}
              <div className="relative w-full max-w-lg aspect-square flex items-center justify-center p-4 sm:p-8">
                <Image
                  src="/illustrations/hero.svg"
                  alt="LKS Achievement Illustration"
                  width={500}
                  height={500}
                  className="w-full h-full object-contain"
                  priority
                />
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 text-muted-foreground">
        <span className="text-sm">Scroll untuk lebih</span>
        <div className="w-6 h-10 border-2 border-muted-foreground rounded-full flex justify-center">
          <div className="w-1.5 h-3 bg-muted-foreground rounded-full mt-2 animate-bounce" />
        </div>
      </div>
    </section>
  )
}
