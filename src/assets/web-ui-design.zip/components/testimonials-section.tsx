"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { ChevronLeft, ChevronRight, Quote } from "lucide-react"

const testimonials = [
  {
    quote: "LKS mengubah hidup saya. Setelah meraih medali emas, saya mendapat beasiswa dan langsung diterima bekerja di perusahaan multinasional.",
    name: "Ahmad Rizki",
    school: "SMKN 1 Bandung",
    achievement: "Medali Emas - Web Development 2023",
    avatar: "AR",
  },
  {
    quote: "Pengalaman berkompetisi di LKS membuat saya lebih percaya diri. Networking dengan peserta dari seluruh Indonesia sangat berharga.",
    name: "Siti Nurhaliza",
    school: "SMKN 3 Surabaya",
    achievement: "Medali Perak - Graphic Design 2023",
    avatar: "SN",
  },
  {
    quote: "Persiapan LKS mengajarkan saya pentingnya dedikasi dan kerja keras. Skill yang saya dapat sangat berguna di dunia kerja.",
    name: "Budi Santoso",
    school: "SMKN 2 Semarang",
    achievement: "Medali Perunggu - Network Administration 2023",
    avatar: "BS",
  },
]

export function TestimonialsSection() {
  const [currentIndex, setCurrentIndex] = useState(0)

  const nextTestimonial = () => {
    setCurrentIndex((prev) => (prev + 1) % testimonials.length)
  }

  const prevTestimonial = () => {
    setCurrentIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length)
  }

  return (
    <section className="py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto">
          <span className="text-primary font-semibold text-sm uppercase tracking-wider">Testimoni</span>
          <h2 className="mt-4 text-3xl sm:text-4xl font-bold text-foreground text-balance">
            Cerita Sukses Alumni LKS
          </h2>
          <p className="mt-4 text-muted-foreground text-lg">
            Dengarkan pengalaman mereka yang telah merasakan manfaat mengikuti LKS.
          </p>
        </div>
        
        {/* Testimonials Carousel */}
        <div className="mt-16 relative">
          <div className="overflow-hidden">
            <div 
              className="flex transition-transform duration-500 ease-in-out"
              style={{ transform: `translateX(-${currentIndex * 100}%)` }}
            >
              {testimonials.map((testimonial, index) => (
                <div key={index} className="w-full flex-shrink-0 px-4">
                  <Card className="max-w-3xl mx-auto">
                    <CardContent className="p-8 sm:p-12">
                      <Quote className="w-12 h-12 text-primary/20 mb-6" />
                      <blockquote className="text-xl sm:text-2xl text-foreground leading-relaxed font-medium">
                        {`"${testimonial.quote}"`}
                      </blockquote>
                      <div className="mt-8 flex items-center gap-4">
                        <div className="w-14 h-14 rounded-full bg-primary flex items-center justify-center text-primary-foreground font-bold text-lg">
                          {testimonial.avatar}
                        </div>
                        <div>
                          <p className="font-semibold text-foreground">{testimonial.name}</p>
                          <p className="text-sm text-muted-foreground">{testimonial.school}</p>
                          <p className="text-sm text-accent font-medium">{testimonial.achievement}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              ))}
            </div>
          </div>
          
          {/* Navigation */}
          <div className="mt-8 flex justify-center items-center gap-4">
            <button
              onClick={prevTestimonial}
              className="w-12 h-12 rounded-full bg-secondary flex items-center justify-center text-foreground hover:bg-primary hover:text-primary-foreground transition-colors"
              aria-label="Previous testimonial"
            >
              <ChevronLeft className="w-6 h-6" />
            </button>
            
            {/* Dots */}
            <div className="flex gap-2">
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentIndex(index)}
                  className={`w-3 h-3 rounded-full transition-colors ${
                    index === currentIndex ? "bg-primary" : "bg-muted-foreground/30"
                  }`}
                  aria-label={`Go to testimonial ${index + 1}`}
                />
              ))}
            </div>
            
            <button
              onClick={nextTestimonial}
              className="w-12 h-12 rounded-full bg-secondary flex items-center justify-center text-foreground hover:bg-primary hover:text-primary-foreground transition-colors"
              aria-label="Next testimonial"
            >
              <ChevronRight className="w-6 h-6" />
            </button>
          </div>
        </div>
      </div>
    </section>
  )
}
