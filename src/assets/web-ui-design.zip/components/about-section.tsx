import { Target, Award, Users, Lightbulb } from "lucide-react"
import Image from "next/image"

const features = [
  {
    icon: Target,
    title: "Kompetisi Berkualitas",
    description: "Standar kompetisi nasional dengan juri berpengalaman dari industri dan akademisi terbaik.",
  },
  {
    icon: Award,
    title: "Prestasi Membanggakan",
    description: "Kesempatan meraih medali emas, perak, perunggu dan menjadi kebanggaan sekolah serta daerah.",
  },
  {
    icon: Users,
    title: "Jaringan Luas",
    description: "Bertemu dengan siswa berbakat dari seluruh Indonesia dan membangun koneksi berharga.",
  },
  {
    icon: Lightbulb,
    title: "Pengembangan Skill",
    description: "Asah kemampuan dan siapkan diri menghadapi tantangan dunia kerja dan industri 4.0.",
  },
]

export function AboutSection() {
  return (
    <section id="about" className="py-20 bg-secondary/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left - Illustration */}
          <div className="relative flex justify-center">
            <div className="relative w-full max-w-lg aspect-square flex items-center justify-center p-4 sm:p-8">
              <Image
                src="/illustrations/about.svg"
                alt="LKS Certificate Achievement"
                width={500}
                height={500}
                className="w-full h-full object-contain"
              />
            </div>
          </div>
          
          {/* Right - Content */}
          <div>
            <span className="text-primary font-semibold text-sm uppercase tracking-wider">Tentang LKS</span>
            <h2 className="mt-4 text-3xl sm:text-4xl font-bold text-foreground text-balance">
              Ajang Kompetisi Siswa SMK Terbesar di Indonesia
            </h2>
            <p className="mt-6 text-muted-foreground text-lg leading-relaxed">
              Lomba Kompetensi Siswa (LKS) adalah kompetisi tahunan yang diselenggarakan oleh Kementerian Pendidikan, Kebudayaan, Riset, dan Teknologi untuk menguji dan mengembangkan kemampuan siswa SMK di berbagai bidang keahlian.
            </p>
            
            {/* Features Grid */}
            <div className="mt-10 grid sm:grid-cols-2 gap-6">
              {features.map((feature, index) => (
                <div key={index} className="flex gap-4">
                  <div className="flex-shrink-0 w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center">
                    <feature.icon className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-foreground">{feature.title}</h3>
                    <p className="mt-1 text-sm text-muted-foreground">{feature.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
