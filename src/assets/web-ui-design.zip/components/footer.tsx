import Link from "next/link"
import { Facebook, Instagram, Twitter, Youtube, Mail, Phone, MapPin } from "lucide-react"

const footerLinks = {
  tentang: [
    { name: "Tentang LKS", href: "#" },
    { name: "Sejarah", href: "#" },
    { name: "Visi & Misi", href: "#" },
    { name: "Struktur Organisasi", href: "#" },
  ],
  lomba: [
    { name: "Bidang Lomba", href: "#" },
    { name: "Syarat Pendaftaran", href: "#" },
    { name: "Sistem Penilaian", href: "#" },
    { name: "FAQ", href: "#" },
  ],
  informasi: [
    { name: "Berita & Artikel", href: "#" },
    { name: "Galeri", href: "#" },
    { name: "Download", href: "#" },
    { name: "Kontak", href: "#" },
  ],
}

const socialLinks = [
  { icon: Facebook, href: "#", label: "Facebook" },
  { icon: Instagram, href: "#", label: "Instagram" },
  { icon: Twitter, href: "#", label: "Twitter" },
  { icon: Youtube, href: "#", label: "YouTube" },
]

export function Footer() {
  return (
    <footer className="bg-foreground text-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Main Footer */}
        <div className="py-16 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-12">
          {/* Brand */}
          <div className="lg:col-span-2">
            <Link href="/" className="flex items-center gap-2">
              <div className="w-12 h-12 rounded-lg bg-primary flex items-center justify-center">
                <span className="text-primary-foreground font-bold text-2xl">L</span>
              </div>
              <span className="font-bold text-2xl">LKS 2024</span>
            </Link>
            <p className="mt-4 text-background/70 max-w-sm">
              Lomba Kompetensi Siswa (LKS) adalah ajang kompetisi bergengsi untuk siswa SMK se-Indonesia dalam berbagai bidang keahlian.
            </p>
            
            {/* Contact Info */}
            <div className="mt-6 space-y-3">
              <a href="mailto:info@lks.kemdikbud.go.id" className="flex items-center gap-3 text-background/70 hover:text-background transition-colors">
                <Mail className="w-5 h-5" />
                info@lks.kemdikbud.go.id
              </a>
              <a href="tel:+6221123456" className="flex items-center gap-3 text-background/70 hover:text-background transition-colors">
                <Phone className="w-5 h-5" />
                +62 21 123456
              </a>
              <div className="flex items-start gap-3 text-background/70">
                <MapPin className="w-5 h-5 mt-0.5" />
                <span>Jl. Jenderal Sudirman, Jakarta Pusat, 10110</span>
              </div>
            </div>
            
            {/* Social Links */}
            <div className="mt-6 flex gap-4">
              {socialLinks.map((social) => (
                <a
                  key={social.label}
                  href={social.href}
                  className="w-10 h-10 rounded-full bg-background/10 flex items-center justify-center hover:bg-primary transition-colors"
                  aria-label={social.label}
                >
                  <social.icon className="w-5 h-5" />
                </a>
              ))}
            </div>
          </div>
          
          {/* Links */}
          <div>
            <h3 className="font-semibold text-lg mb-4">Tentang</h3>
            <ul className="space-y-3">
              {footerLinks.tentang.map((link) => (
                <li key={link.name}>
                  <Link href={link.href} className="text-background/70 hover:text-background transition-colors">
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
          
          <div>
            <h3 className="font-semibold text-lg mb-4">Lomba</h3>
            <ul className="space-y-3">
              {footerLinks.lomba.map((link) => (
                <li key={link.name}>
                  <Link href={link.href} className="text-background/70 hover:text-background transition-colors">
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
          
          <div>
            <h3 className="font-semibold text-lg mb-4">Informasi</h3>
            <ul className="space-y-3">
              {footerLinks.informasi.map((link) => (
                <li key={link.name}>
                  <Link href={link.href} className="text-background/70 hover:text-background transition-colors">
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>
        
        {/* Bottom Bar */}
        <div className="py-6 border-t border-background/10 flex flex-col sm:flex-row justify-between items-center gap-4">
          <p className="text-background/60 text-sm">
            © 2024 Lomba Kompetensi Siswa. Kementerian Pendidikan, Kebudayaan, Riset, dan Teknologi.
          </p>
          <div className="flex gap-6 text-sm">
            <Link href="#" className="text-background/60 hover:text-background transition-colors">
              Kebijakan Privasi
            </Link>
            <Link href="#" className="text-background/60 hover:text-background transition-colors">
              Syarat & Ketentuan
            </Link>
          </div>
        </div>
      </div>
    </footer>
  )
}
