import { Card, CardContent } from "@/components/ui/card"
import { ComputerIllustration, MedalIllustration, RocketIllustration } from "@/components/illustrations"
import { Code, Palette, Wrench, ChefHat, Stethoscope, Building2, Plane, Shirt, LucideIcon } from "lucide-react"

interface Category {
  icon: LucideIcon
  name: string
  count: number
  color: string
}

const categories: Category[] = [
  { icon: Code, name: "Teknologi Informasi", count: 8, color: "bg-primary text-primary-foreground" },
  { icon: Palette, name: "Seni & Desain", count: 6, color: "bg-accent text-accent-foreground" },
  { icon: Wrench, name: "Teknik & Manufaktur", count: 12, color: "bg-primary/80 text-primary-foreground" },
  { icon: ChefHat, name: "Kuliner & Hospitality", count: 5, color: "bg-accent/80 text-accent-foreground" },
  { icon: Stethoscope, name: "Kesehatan", count: 4, color: "bg-primary/60 text-primary-foreground" },
  { icon: Building2, name: "Bisnis & Manajemen", count: 6, color: "bg-accent/60 text-accent-foreground" },
  { icon: Plane, name: "Pariwisata", count: 4, color: "bg-primary/70 text-primary-foreground" },
  { icon: Shirt, name: "Fashion & Tekstil", count: 5, color: "bg-accent/70 text-accent-foreground" },
]

export function CategoriesSection() {
  return (
    <section id="categories" className="py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto">
          <span className="text-primary font-semibold text-sm uppercase tracking-wider">Bidang Lomba</span>
          <h2 className="mt-4 text-3xl sm:text-4xl font-bold text-foreground text-balance">
            50+ Bidang Keahlian Siap Bersaing
          </h2>
          <p className="mt-4 text-muted-foreground text-lg">
            Pilih bidang keahlianmu dan tunjukkan kemampuan terbaikmu di tingkat nasional.
          </p>
        </div>
        
        {/* Illustrations Row */}
        <div className="mt-12 flex justify-center items-center gap-8 flex-wrap">
          <ComputerIllustration className="w-48 h-36 opacity-80" />
          <MedalIllustration className="w-32 h-32 opacity-80" />
          <RocketIllustration className="w-32 h-32 opacity-80" />
        </div>
        
        {/* Categories Grid */}
        <div className="mt-12 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
          {categories.map((category, index) => (
            <Card 
              key={index} 
              className="group cursor-pointer hover:shadow-lg transition-all duration-300 hover:-translate-y-1 border-2 border-transparent hover:border-primary/20"
            >
              <CardContent className="p-6">
                <div className={`w-12 h-12 rounded-xl ${category.color} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                  <category.icon className="w-6 h-6" />
                </div>
                <h3 className="font-semibold text-foreground group-hover:text-primary transition-colors">
                  {category.name}
                </h3>
                <p className="mt-1 text-sm text-muted-foreground">
                  {category.count} bidang
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
        
        {/* View All Link */}
        <div className="mt-10 text-center">
          <a href="#" className="inline-flex items-center gap-2 text-primary font-medium hover:underline">
            Lihat semua bidang lomba
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </a>
        </div>
      </div>
    </section>
  )
}
