import { TeamworkIllustration, WavePattern } from "@/components/illustrations"
import { Button } from "@/components/ui/button"
import { ArrowRight, FileText, Phone } from "lucide-react"

export function CTASection() {
  return (
    <section className="relative py-20 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-primary" />
      <div className="absolute inset-0 opacity-10">
        <TeamworkIllustration className="w-full h-full object-cover" />
      </div>
      
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto">
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-primary-foreground text-balance">
            Siap Menjadi Juara LKS 2024?
          </h2>
          <p className="mt-6 text-lg text-primary-foreground/80 max-w-2xl mx-auto">
            Jangan lewatkan kesempatan untuk mengukir prestasi dan membuktikan kemampuanmu. Daftarkan dirimu sekarang dan jadilah bagian dari sejarah LKS!
          </p>
          
          <div className="mt-10 flex flex-wrap justify-center gap-4">
            <Button 
              size="lg" 
              variant="secondary"
              className="gap-2 bg-primary-foreground text-primary hover:bg-primary-foreground/90"
            >
              <FileText className="w-5 h-5" />
              Daftar Sekarang
              <ArrowRight className="w-4 h-4" />
            </Button>
            <Button 
              size="lg" 
              variant="outline"
              className="gap-2 border-primary-foreground text-primary-foreground hover:bg-primary-foreground/10"
            >
              <Phone className="w-5 h-5" />
              Hubungi Panitia
            </Button>
          </div>
          
          {/* Quick Stats */}
          <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-8">
            <div>
              <p className="text-4xl font-bold text-primary-foreground">50+</p>
              <p className="text-primary-foreground/70">Bidang Lomba</p>
            </div>
            <div>
              <p className="text-4xl font-bold text-primary-foreground">34</p>
              <p className="text-primary-foreground/70">Provinsi</p>
            </div>
            <div>
              <p className="text-4xl font-bold text-primary-foreground">10K+</p>
              <p className="text-primary-foreground/70">Peserta</p>
            </div>
            <div>
              <p className="text-4xl font-bold text-primary-foreground">100+</p>
              <p className="text-primary-foreground/70">Medali</p>
            </div>
          </div>
        </div>
      </div>
      
      {/* Wave at bottom */}
      <div className="absolute bottom-0 left-0 right-0">
        <WavePattern className="w-full h-24 text-background" />
      </div>
    </section>
  )
}
